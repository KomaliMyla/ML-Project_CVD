# Machine-Learning-Project-Starter
Repository of all project documentation and Code

About the status of my project, I would say I did get better understanding about my dataset and how it would help in acheiving the outcomes I hope to.
I plan to add more data like more features into the dataset if possible and see if that helps me get more accurate results.
Initial_exploration:
This notebook was fun to explore and to work on the dataset initially before deep diving into it.
Cleaning the data has so much to work with and I have only tried few to begin with like removing some unneccesary columns and sorting the data.
Linear_regression:
This notebook got very Interesting , calculating the metrics helps very much in understanding the relation between features and the prediction.
As I can see, my metrics doesnt look good but I would like to work on that.
Working on the visualization part was really fun, I have tried with different features to see how the result would change.
I have worked on the visualization to see how my data would results for those parameters.



# Project Milestone 2
# My Observations
Compared to Milestone 1, my dataset looks pretty good with metrics after applying different methods.
What I have noticed is that, even with the same dataset but using different approaches like using SVM and Forest prediction methods really effected the metrics which eventually helps in predicting the outcomes more accurately and hopefully with less errors.

